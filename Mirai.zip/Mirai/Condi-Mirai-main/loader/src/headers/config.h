#pragma once

#define HTTP_SERVER "40.123.254.127"
#define HTTP_PORT 80

#define TFTP_SERVER "40.123.254.127"
